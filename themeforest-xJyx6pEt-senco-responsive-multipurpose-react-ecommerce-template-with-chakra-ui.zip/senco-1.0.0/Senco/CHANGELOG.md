# Changelog

All notable changes to this project will be documented in this file. Visit [Senco Template](https://senco.themebiotic.com/) website for more details.
## [1.0.0](#) (2022-10-19)
