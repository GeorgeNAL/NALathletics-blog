export default {
  lg: "18px",
  "5xl": "46px",
};
