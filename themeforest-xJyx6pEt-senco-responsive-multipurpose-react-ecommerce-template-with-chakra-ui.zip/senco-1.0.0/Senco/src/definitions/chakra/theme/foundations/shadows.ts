export default {
  outline: "0 0 0 3px var(--chakra-colors-brand-100)",
};
