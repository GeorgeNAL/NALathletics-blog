export default function percentage(x: number, y: number) {
  return 100 / (y / x);
}
