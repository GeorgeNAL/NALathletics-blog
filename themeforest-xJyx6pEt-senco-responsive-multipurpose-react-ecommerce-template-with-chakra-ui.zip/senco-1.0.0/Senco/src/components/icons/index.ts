export { SecurePaymentIcon } from "./secure-payment";
export { PackageReturnIcon } from "./package-return";
export { FreeShippingIcon } from "./free-shipping";
