# Assets

All Graphics content used on the site will be located in this folder.

